/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import za.ac.tut.model.bl.QuizSBLocal;

/**
 *
 * @author ALICIA TAU
 */
public class OutcomeServlet extends HttpServlet {

    @EJB QuizSBLocal qsl;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        String userAnswer = request.getParameter("answer");
        int num1 = (Integer)session.getAttribute("num1");
        int num2 = (Integer)session.getAttribute("num2");
        String correctAnswer = qsl.getAnswer(num1, num2);
        
        String outcome = qsl.determineOutcome(userAnswer, correctAnswer);
        updateSession(session,outcome,userAnswer,correctAnswer);
        
        request.setAttribute("userAnswer", userAnswer);
        request.setAttribute("correctAnswer", correctAnswer);
        request.setAttribute("outcome", outcome);
        
        RequestDispatcher disp = request.getRequestDispatcher("outcome.jsp");
        disp.forward(request, response);
    }

    private void updateSession(HttpSession session, String outcome, String userAnswer, String correctAnswer) {
        List<String> questions = (List<String>)session.getAttribute("questions");
        List<String> answers = (List<String>)session.getAttribute("answers");
        List<String> usersAnswers = (List<String>)session.getAttribute("usersAnswers");
        String question = (String)session.getAttribute("question");
        int numQuestionsAsked = (Integer)session.getAttribute("numQuestionsAsked");
        int numCorrectAnswers = (Integer)session.getAttribute("numCorrectAnswers");
        int numWrongAnswers = (Integer)session.getAttribute("numWrongAnswers");
    
        if(outcome.equals("Correct")){
            numCorrectAnswers++;
            session.setAttribute("numCorrectAnswers", numCorrectAnswers);
        }else{
            numWrongAnswers++;
            session.setAttribute("numWrongAnswers", numWrongAnswers);
        }
        
        questions.add(question);
        session.setAttribute("questions", questions);
        
        answers.add(correctAnswer);
        session.setAttribute("answers", answers);
        
        usersAnswers.add(userAnswer);
        session.setAttribute("usersAnswers", usersAnswers);
        
        numQuestionsAsked++;
        session.setAttribute("numQuestionsAsked", numQuestionsAsked);
    }

}
